<h1 align='center'>NavGeevan Hospital</h1>

<?php echo $__env->make('template.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH F:\laravel\hospital\resources\views/template/header.blade.php ENDPATH**/ ?>