<?php $__env->startSection('content'); ?>
<h3 align='center'>NavGeevan Hospital</h3>


<table class="table">
  <thead >
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Name</th>
      <th scope="col">Delete</th>
      <th scope="col">Update</th>
    </tr>
  </thead>
<?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tbody>
    <tr>
      <th scope="row"><?php echo e($patient->id); ?></th>
      <td>
        <a href="<?php echo e(route('hospital.show',$patient->id)); ?>">
        <?php echo e($patient->name); ?>

        </a>
      </td>
      <td>
        <form action="<?php echo e(route('hospital.destroy',$patient->id)); ?>" method ="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <input type="submit" value="Trash" class="btn btn-danger"/>  
        </form>
      </td>
      <td>
      </td>
    </tr>
  </tbody>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\MCA_Sem_2\hospital\resources\views/hospital/index.blade.php ENDPATH**/ ?>