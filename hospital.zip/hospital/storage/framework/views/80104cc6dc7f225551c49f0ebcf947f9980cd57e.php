<?php $__env->startSection('contents'); ?>
<h3 align='center'>NavGeevan Hospital</h3>
<h4>Patient Name :- <?php echo e($hospital->name); ?> </h4>

<hr>
<h5>Disease :-</h5>
<h6><?php echo e($hospital->disease); ?></h6>
<h5>Medicines :-</h5>
<h6><?php echo e($hospital->medicines); ?></h6>

<form action="" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
    <label>Example textarea</label>
    <textarea class="form-control" rows="3"></textarea>
    </div>
    <input type="submit" value="Visit Info" class="btn btn-primary">
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\hospital\resources\views/hospital/show.blade.php ENDPATH**/ ?>