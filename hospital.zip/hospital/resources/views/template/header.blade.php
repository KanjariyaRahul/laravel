<h1 align='center'>NavGeevan Hospital</h1>

@include('template.menu')
