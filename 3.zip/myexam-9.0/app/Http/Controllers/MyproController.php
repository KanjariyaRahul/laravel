<?php

namespace App\Http\Controllers;

use App\Models\Mypro;
use Illuminate\Http\Request;

class MyproController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $mydata = Mypro::get();
        return view('user.home',compact('mydata'));
    }

   
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view('user.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Mypro::create($request->all());
        return redirect()->route('Mypro.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Mypro  $mypro
     * @return \Illuminate\Http\Response
     */
    public function show(Mypro $Mypro)
    {
        return view('user.show',compact('Mypro'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Mypro  $mypro
     * @return \Illuminate\Http\Response
     */
    public function edit(Mypro $Mypro)
    {
        
        return view('user.edit',compact('Mypro'));
    }

    public function update(Request $request,Mypro $Mypro )
    {

        $Mypro->update($request->all());
        return redirect()->route('Mypro.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Mypro  $mypro
     * @return \Illuminate\Http\Response
     */
    public function destroy(Mypro $Mypro)
    {
        $Mypro->delete();
        return redirect()->route('Mypro.index');
    }
}
