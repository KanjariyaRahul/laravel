<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/ckeditor.js')); ?>"></script>
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
  </head>
  <body>
    <h1 align="center">My Program</h1>
    <?php echo $__env->make('template.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

  </body>
</html><?php /**PATH D:\MCA\Sem 2\Github\Laravel\myexam-9.0\resources\views/template/sample-layout.blade.php ENDPATH**/ ?>