<h1>My Blog</h1>
<?php echo $__env->make('template.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Laravel\myapp\resources\views/template/header.blade.php ENDPATH**/ ?>