<?php $__env->startSection('content'); ?>
<h1>All the information will be displayed here....</h1>
<table class="table table-hover table-stripped table-sm table">
<thead>
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Subtitle</th>
        <th>View</th>
        <th>Edit</th>
        <th>Delete</th>
    </tr>
</thead>
<tbody>
    <?php $__empty_1 = true; $__currentLoopData = $myblogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myblog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($myblog->id); ?></td>
            <td><?php echo e($myblog->title); ?></td>
            <td><?php echo e($myblog->subtitle); ?></td>
            <td>View</td>
            <td>
                <a class="btn btn-sm btn-warning" href="<?php echo e(route('myblog.edit', $myblog->id)); ?>">Edit Me!</a>
            </td>
            <td>Delete</td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan=6>No Data Avaialble</td>
    </tr>
    <?php endif; ?>
</tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\myapp\resources\views/user/index.blade.php ENDPATH**/ ?>