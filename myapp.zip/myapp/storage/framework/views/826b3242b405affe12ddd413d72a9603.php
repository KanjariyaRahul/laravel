<?php $__env->startSection('content'); ?>
<h1>Add your Blog Post Here....</h1>
<form action="<?php echo e(route('myblog.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label>Title</label>
      <input type="text" name="title" class="form-control" placeholder="Enter title">
    </div>
    <div class="form-group">
        <input type="hidden" name="user_id" value="1">
        <label>Subtitle</label>
        <input type="text" name="subtitle" class="form-control" placeholder="Enter subtitle">
    </div>
    <div class="form-group">
        <label>Body Content</label>
        <textarea class="form-control" name="body_content" placeholder="Leave a comment here" id="editor"></textarea>
        <script>
            ClassicEditor
                .create( document.querySelector( '#editor' ) )
                .catch( error => {
                    console.error( error );
                } );
        </script>
      </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-tags'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/41.1.0/classic/ckeditor.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\myapp\resources\views/user/create.blade.php ENDPATH**/ ?>