<h1>My Blog</h1>
@include('template.menu')
