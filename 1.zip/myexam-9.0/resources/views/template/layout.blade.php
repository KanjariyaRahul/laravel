<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <script src="{{ asset('js/bootstrap.js') }}" ></script>
    <script src="{{ asset('js/ckeditor.js') }}"></script>
    <link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet">
  </head>
  <body>
    <h1 align="center">My Program</h1>
    @include('template.nav')
    @yield('content')
    @include('template.footer')
  </body>
</html>