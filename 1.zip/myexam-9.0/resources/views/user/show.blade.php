@extends('template.layout')
@section('content')

<h2>Name : {{$Mypro->name}} </h2>
<h2>City: {{$Mypro->city}} </h2>
<h2>Mobile : {{$Mypro->phone}} </h2>
<h2>Address : {!!$Mypro->address!!} </h2>

@endsection