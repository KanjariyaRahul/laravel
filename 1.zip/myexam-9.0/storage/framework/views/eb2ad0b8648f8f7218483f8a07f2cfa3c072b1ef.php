
<?php $__env->startSection('content'); ?>

<h2>Name : <?php echo e($Mypro->name); ?> </h2>
<h2>City: <?php echo e($Mypro->city); ?> </h2>
<h2>Mobile : <?php echo e($Mypro->phone); ?> </h2>
<h2>Address : <?php echo $Mypro->address; ?> </h2>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\myexam-9.0\resources\views/user/show.blade.php ENDPATH**/ ?>