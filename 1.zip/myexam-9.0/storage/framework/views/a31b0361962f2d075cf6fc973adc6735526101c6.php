
<?php $__env->startSection('content'); ?>
    <h2 align="center">Edit Data</h2>
    <div class="container">

        <form method="POST" action="<?php echo e(route('Mypro.update',$data->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="form-group">
                <label for="exampleInputEmail1">Name</label>
                <input type="text" name="name" class="form-control" value="<?php echo e($data->name); ?>"
                    placeholder="Enter your name">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">City</label>
                <input type="text" name="city" class="form-control" id="exampleInputPassword1"value="<?php echo e($data->city); ?>"
                    placeholder="Enter Your city">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Phone</label>
                <input type="text" name="phone" class="form-control" id="exampleInputPassword1"value="<?php echo e($data->phone); ?>"
                    placeholder="Enter Your Phone Number">
            </div>
            <label for="exampleInputPassword1">Address</label>
            <textarea class="form-control" id="editor" name="address" rows="3"><?php echo $data->address; ?></textarea>

            <script>
                ClassicEditor
                    .create(document.querySelector('#editor'))
                    .catch(error => {
                        console.error(error);
                    });
            </script>
            <div style="display: flex; justify-content: center; margin-top: 10px;">

                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.sample-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MCA\Sem 2\Github\Laravel\myexam-9.0\resources\views/user/edit.blade.php ENDPATH**/ ?>