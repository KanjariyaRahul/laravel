
<?php $__env->startSection('content'); ?>

<h1 align="center">My Data</h1>

<table class="table table-striped table-hover">
    <thead>
        <th>Id</th>
        <th>Name</th>
        <th>City</th>
        <th>Edit</th>
        <th>Delete</th>
        <th>Show</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $mydata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data->id); ?></td>
                <td><?php echo e($data->name); ?></td>
                <td><?php echo e($data->city); ?></td>
                <td><a href="<?php echo e(route('Mypro.edit' , $data->id)); ?>" class="btn btn-warning">Edit</a></td>
                <td>
                    <form action="<?php echo e(route('Mypro.destroy',$data->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="submit" value="Delete" class="btn btn-danger">
                    </form>
                </td>
                <td><a href="<?php echo e(route('Mypro.show',$data->id)); ?>" class="btn btn-primary">Show</a></td>
            </tr>
        
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.sample-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MCA\Sem 2\Github\Laravel\myexam-9.0\resources\views/user/home.blade.php ENDPATH**/ ?>