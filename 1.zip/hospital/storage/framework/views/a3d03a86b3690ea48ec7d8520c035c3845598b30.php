<?php $__env->startSection('content'); ?>
<h3 align='center'>NavGeevan Hospital</h3>

<h4>Patient Name :- <?php echo e($hospital->name); ?> </h4>

<hr>
<h5>Disease :-</h5>
<h6><?php echo e($hospital->disease); ?></h6>
<h5>Medicines :-</h5>
<h6><?php echo e($hospital->medicines); ?></h6>

<?php
    $i= 1;
?>
<ul>
<?php $__empty_1 = true; $__currentLoopData = $hospital->getVisits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <li>
        <label for="">Visits : <?php echo e($i++); ?></label>
        <p><?php echo e($visit->med_diseases); ?></p>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <li>No More visits found</li>
<?php endif; ?>
</ul>

<form action="<?php echo e(route('visit.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="patients_id" value= <?php echo e($hospital->id); ?> >
    <div class="form-group">
    <label>Example textarea</label>
    <textarea name="med_diseases" class="form-control" rows="3"></textarea>
    </div>
    <input type="submit"  value="Visit Info" class="btn btn-primary">
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\MCA_Sem_2\hospital\resources\views/hospital/show.blade.php ENDPATH**/ ?>