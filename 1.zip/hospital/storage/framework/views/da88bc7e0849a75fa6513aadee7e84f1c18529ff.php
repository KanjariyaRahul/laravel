<h4>Developed By :- Mahaveersinh</h4>
<?php /**PATH F:\laravel\hospital\resources\views/template/footer.blade.php ENDPATH**/ ?>