<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="container">
    <form method="post" class="border-" >
        <h1 style="text-align: center">ADD POST </h1><hr>
        <div class="form-group" >
          <label>Title</label>
          <input type="text" class="form-control" placeholder="Enter Title" name="">
        </div>
        <div class="form-group">
          <label >Sub Title</label>
          <input type="text" class="form-control" placeholder="Enter Sub Title">
        </div>
        <div class="form-group">
            <textarea name="" id="" class="form-control" cols="30" rows="10"></textarea>
        </div>
        <div class="form-group">
        <button type="submit" class="btn btn-primary ">Submit</button>
        <button type="reset" class="btn btn-primary">Reset</button>
        </div>
      </form>
    </div>
</body>
</html>
<?php /**PATH E:\laravel\site\resources\views/Mypost/Create.blade.php ENDPATH**/ ?>